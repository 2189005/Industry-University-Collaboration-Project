package com.example.movierecommender;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private EditText userIdEditText, mbtiTypeEditText;
    private Button userRecommendButton, mbtiRecommendButton;
    private TextView recommendationsTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userIdEditText = findViewById(R.id.user_id);
        mbtiTypeEditText = findViewById(R.id.mbti_type);
        userRecommendButton = findViewById(R.id.user_recommend_button);
        mbtiRecommendButton = findViewById(R.id.mbti_recommend_button);
        recommendationsTextView = findViewById(R.id.recommendations);

        
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        userRecommendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userId = userIdEditText.getText().toString();
                if (!userId.isEmpty()) {
                    String recommendations = getUserRecommendations(userId);
                    recommendationsTextView.setText(recommendations);
                }
            }
        });

        mbtiRecommendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mbtiType = mbtiTypeEditText.getText().toString();
                if (!mbtiType.isEmpty()) {
                    String recommendations = getMbtiRecommendations(mbtiType);
                    recommendationsTextView.setText(recommendations);
                }
            }
        });
    }

    private String getUserRecommendations(String userId) {
        String response = "";
        try {
            String urlString = "http://10.0.2.2:5000/recommend?user_id=" + userId;
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
            StringBuilder content = new StringBuilder();
            while ((inputLine = in.readLine()) != null) {
                content.append(inputLine);
            }

            in.close();
            conn.disconnect();
            response = content.toString();
        } catch (Exception e) {
            e.printStackTrace();
            response = "Error fetching recommendations.";
        }
        return response;
    }

    private String getMbtiRecommendations(String mbtiType) {
        String response = "";
        try {
            String urlString = "http://10.0.2.2:5000/mbti_recommend?mbti_type=" + mbtiType;
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
            StringBuilder content = new StringBuilder();
            while ((inputLine = in.readLine()) != null) {
                content.append(inputLine);
            }

            in.close();
            conn.disconnect();
            response = content.toString();
        } catch (Exception e) {
            e.printStackTrace();
            response = "Error fetching recommendations.";
        }
        return response;
    }
}
